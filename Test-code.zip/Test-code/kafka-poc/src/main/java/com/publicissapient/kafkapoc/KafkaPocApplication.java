package com.publicissapient.kafkapoc;

import com.publicissapient.kafkapoc.model.Sensor;
import com.publicissapient.kafkapoc.simple.Producer;
import com.publicissapient.kafkapoc.simple.ProducerAvro;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

@SpringBootApplication
public class KafkaPocApplication implements CommandLineRunner {

	public static void main(String[] args) {

		SpringApplication.run(KafkaPocApplication.class, args);
	}

	@Autowired
	private Producer producer;

	@Autowired
	private ProducerAvro producerAvro;

	@Override
	public void run(String... strings) throws Exception {
		//producer.sendMessage();
		producerAvro.customMessage();
	}
}

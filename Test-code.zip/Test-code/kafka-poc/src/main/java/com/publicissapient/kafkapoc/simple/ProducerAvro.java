package com.publicissapient.kafkapoc.simple;

import com.publicissapient.kafkapoc.model.Sensor;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.SerializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class ProducerAvro {

    @Value("${application.topic.message-topic}")
    private String topic;

    private final KafkaTemplate<String, Sensor> kafkaTemplate;

    @Autowired
    public ProducerAvro(KafkaTemplate<String, Sensor> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }





    public void sendMessage(Sensor sensor) {
        this.kafkaTemplate.send(this.topic, sensor.getSensorID(),sensor);
        System.out.println(String.format("Produced user -> %s", sensor));

    }

    public void  customMessage(){
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                io.confluent.kafka.serializers.KafkaAvroSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                io.confluent.kafka.serializers.KafkaAvroSerializer.class);
        props.put("schema.registry.url", "http://localhost:8081");
        KafkaProducer producer = new KafkaProducer(props);

        String key = "key1";
        String userSchema = "{\"type\":\"record\"," +
                "\"name\":\"myrecord\"," +
                "\"fields\":[{\"name\":\"sensorID\",\"type\":\"string\"},{\"name\":\"sensorType\",\"type\":\"string\"},{\"name\":\"payLoad\",\"type\":\"string\"}]}";
        Schema.Parser parser = new Schema.Parser();
        Schema schema = parser.parse(userSchema);
        GenericRecord avroRecord = new GenericData.Record(schema);
        avroRecord.put("sensorID", "humidity");
        avroRecord.put("sensorType", "humiditySensor");
        avroRecord.put("payLoad", "60");

        ProducerRecord<Object, Object> record = new ProducerRecord<>(topic, key, avroRecord);
        try {
            producer.send(record);
            System.out.println("Avro Message sent to topic");
        } catch(SerializationException e) {
            // may need to do something with it
        }
        finally {
            producer.flush();
            producer.close();
        }
    }




}

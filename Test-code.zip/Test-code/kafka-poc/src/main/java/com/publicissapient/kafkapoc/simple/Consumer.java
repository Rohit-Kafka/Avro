package com.publicissapient.kafkapoc.simple;
import com.publicissapient.kafkapoc.model.Sensor;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class Consumer {
    @KafkaListener(topics = "${application.topic.message-topic}", groupId = "${spring.kafka.consumer.group-id}")
    public void onMessage(final ConsumerRecord<String, String> consumerRecord) throws IOException {
        // Use For simple consumer
        //Sensor sensor = new ObjectMapper().readValue(consumerRecord.value(), Sensor.class);
       // System.out.println("Received Messasge: " + sensor.toString());

        // Use for Avro
        System.out.println(consumerRecord.toString());
    }
}

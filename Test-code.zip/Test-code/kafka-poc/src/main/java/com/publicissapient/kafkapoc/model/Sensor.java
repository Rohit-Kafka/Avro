package com.publicissapient.kafkapoc.model;
import lombok.*;

import java.io.Serializable;


@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Sensor implements Serializable {
    private String sensorID;
    private String sensorType;
    private String payLoad;
}

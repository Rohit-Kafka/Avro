package com.publicissapient.kafkapoc.simple;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class Producer {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value("${application.topic.message-topic}")
    private String topic;

    public void sendMessage() {
        kafkaTemplate.send(topic, createMessage());
        System.out.println("Message Send");
    }

    private String createMessage() {
        return "{  \n" +
                "   \"sensorID\":\"new-york\",\n" +
                "   \"sensorType\":\"Temparture\",\n" +
                "   \"payLoad\":\"45.0C\"\n" +
                "}";
    }
}
